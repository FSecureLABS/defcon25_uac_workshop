function Get-AutoElevate {
<#
.SYNOPSIS
	Depth limited wrapper for Get-ChildItem & Get-Content to find Auto-Elevating binaries.
	Totally inefficient but just grab a coffee!
	
.DESCRIPTION
	Author: Ruben Boonen (@FuzzySec)
	License: BSD 3-Clause
	Required Dependencies: None
	Optional Dependencies: None

.PARAMETER Path
	Top level path (local or UNC).

.PARAMETER MaxDepth
	Folder depth.

.EXAMPLE
	C:\PS> Get-AutoElevate -Path C:\Windows\System32 -MaxDepth 1
#>
	param(
		[Parameter(Mandatory = $true)]
		$Path,
		[UInt32]$MaxDepth=3
	)
	
	# AutoElevate regex
	$ElevateRegex = [regex] '(?is)(?<=\bautoElevate>\b).*?(?=\b</autoElevate\b)'
	
	# Array to hold search results
	$ElevateArray = @()

	# Search
	for ($i=1;$i-lt$($MaxDepth+1);$i++){
		$SearchPath = $Path + ("\*"*$i)
		$ResultObject = Get-ChildItem -Path $SearchPath -ErrorAction SilentlyContinue
		$PathList = $ResultObject|Where {!$_.PSIsContainer} |
		ForEach-Object {
			if ($_.Name -like "*.exe"){
				$RegexMatch = $ElevateRegex.Matches($(Get-Content -ReadCount 10000 -Path $_.FullName))
				if(($RegexMatch|Select Success).Success) {
					$Value = ($RegexMatch|Select Value).Value
					$HashTable = @{
						Path = $_.FullName
						Elevate = $Value
					}
					$Object = New-Object PSObject -Property $HashTable
					$ElevateArray += $Object
				}
			}
		}
	}
	
	# Print results
	$ElevateArray
}